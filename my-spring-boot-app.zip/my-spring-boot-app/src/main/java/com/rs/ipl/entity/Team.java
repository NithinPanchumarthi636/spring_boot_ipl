package com.rs.ipl.entity;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name="team")
public class Team {

	@Id
	@Column(name= "team_id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	
	@Column
	private String name;
	@Column
	private String state;
	@Column
	private String captain;
	@Column
	private String coach;
	@Column
	private List<String> players;
	@Column
	private int matches;

}