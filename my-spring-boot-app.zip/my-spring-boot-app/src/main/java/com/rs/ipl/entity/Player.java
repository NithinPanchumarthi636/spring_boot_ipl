package com.rs.ipl.entity;

public class Player {

}
