package com.rs.myspringbootapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MySpringBootAppIplApplication {

	public static void main(String[] args) {
		SpringApplication.run(MySpringBootAppIplApplication.class, args);
	}

}
