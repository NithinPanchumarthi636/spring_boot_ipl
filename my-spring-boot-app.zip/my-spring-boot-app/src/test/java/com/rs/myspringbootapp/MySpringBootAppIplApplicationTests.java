/*
 * //package com.rs.myspringbootapp; // //import
 * org.springframework.boot.SpringApplication; //import
 * org.springframework.boot.test.context.SpringBootTest; // // //@SpringBootTest
 * //class MySpringBootAppIplApplicationTests { // // //}
 */