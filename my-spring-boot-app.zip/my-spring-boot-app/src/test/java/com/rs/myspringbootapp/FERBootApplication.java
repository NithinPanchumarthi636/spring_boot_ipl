package com.rs.myspringbootapp;

public class FERBootApplication {

}
